package com.makkigame;

import org.joml.Matrix4f;
import org.joml.Vector3f;

public class Camera {
    public float posX, posY, posZ;
    public float pitch, yaw;
    public final float movementSpeed = 3.0f;
    public final float mouseSensitivity = 0.1f;

    private boolean firstMouse = true;
    private double lastMouseX, lastMouseY;

    public Camera(float posX, float posY, float posZ, float pitch, float yaw) {
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
        this.pitch = pitch;
        this.yaw = yaw;
    }

    public float[] getForwardVector() {
        float cosP = (float) Math.cos(Math.toRadians(pitch));
        float sinP = (float) Math.sin(Math.toRadians(pitch));
        float cosY = (float) Math.cos(Math.toRadians(yaw));
        float sinY = (float) Math.sin(Math.toRadians(yaw));
        return new float[] { cosP * sinY, sinP, cosP * cosY };
    }

    public Matrix4f getViewMatrix() {
        Vector3f eye = new Vector3f(posX, posY, posZ);
        float[] fwd = getForwardVector();
        Vector3f center = new Vector3f(
                posX + fwd[0],
                posY + fwd[1],
                posZ + fwd[2]);
        return new Matrix4f().lookAt(eye, center, new Vector3f(0, 1, 0));
    }

    public void handleMouseMovement(double xpos, double ypos) {
        if (firstMouse) {
            lastMouseX = xpos;
            lastMouseY = ypos;
            firstMouse = false;
        }
        double dx = xpos - lastMouseX;
        double dy = lastMouseY - ypos;
        lastMouseX = xpos;
        lastMouseY = ypos;
        yaw += dx * mouseSensitivity;
        pitch += dy * mouseSensitivity;
        pitch = Math.min(89f, Math.max(-89f, pitch));
    }

    public void move(float[] dir, float dt) {
        posX += dir[0] * movementSpeed * dt;
        posY += dir[1] * movementSpeed * dt;
        posZ += dir[2] * movementSpeed * dt;
    }

    public void strafe(float dt) {
        float[] dir = getForwardVector();
        posX += -dir[2] * movementSpeed * dt;
        posZ += dir[0] * movementSpeed * dt;
    }

    public void fly(float dt) {
        posY += dt * movementSpeed;
    }
}