package com.makkigame;

import static org.lwjgl.opengl.GL20.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.joml.Matrix4f;
import org.joml.Vector3f;

public class ShaderProgram {
    private final int programId;

    public ShaderProgram(String vertPath, String fragPath) {
        int vid = loadShader(vertPath, GL_VERTEX_SHADER);
        int fid = loadShader(fragPath, GL_FRAGMENT_SHADER);
        programId = glCreateProgram();
        if (programId == 0) {
            throw new RuntimeException("Could not create shader program");
        }
        glAttachShader(programId, vid);
        glAttachShader(programId, fid);
        glLinkProgram(programId);
        if (glGetProgrami(programId, GL_LINK_STATUS) == 0) {
            throw new RuntimeException("Error linking shader: " + glGetProgramInfoLog(programId, 1024));
        }
        glValidateProgram(programId);
        glDetachShader(programId, vid);
        glDetachShader(programId, fid);
        glDeleteShader(vid);
        glDeleteShader(fid);
    }

    private int loadShader(String path, int type) {
        try {
            String code = new String(Files.readAllBytes(Paths.get(getClass()
                    .getClassLoader()
                    .getResource(path)
                    .toURI())));
            int id = glCreateShader(type);
            glShaderSource(id, code);
            glCompileShader(id);
            if (glGetShaderi(id, GL_COMPILE_STATUS) == 0) {
                throw new RuntimeException("Error compiling shader: " + glGetShaderInfoLog(id, 1024));
            }
            return id;
        } catch (Exception e) {
            throw new RuntimeException("Failed to load shader: " + path, e);
        }
    }

    public void bind() {
        glUseProgram(programId);
    }

    public void unbind() {
        glUseProgram(0);
    }

    public void cleanup() {
        unbind();
        glDeleteProgram(programId);
    }

    public void setUniform(String name, Matrix4f mat) {
        int loc = glGetUniformLocation(programId, name);
        float[] arr = new float[16];
        mat.get(arr);
        glUniformMatrix4fv(loc, false, arr);
    }

    public void setUniform(String name, Vector3f vec) {
        int loc = glGetUniformLocation(programId, name);
        glUniform3f(loc, vec.x, vec.y, vec.z);
    }

    public void setUniform(String name, int val) {
        int loc = glGetUniformLocation(programId, name);
        glUniform1i(loc, val);
    }
}