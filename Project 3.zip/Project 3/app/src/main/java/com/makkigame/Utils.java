package com.makkigame;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Utils {
    public static ByteBuffer ioResourceToByteBuffer(String resource, int bufferSize) throws IOException {
        URL url = Utils.class.getClassLoader().getResource(resource);
        if (url == null) {
            throw new FileNotFoundException("Resource not found: " + resource);
        }
        Path path;
        try {
            path = Paths.get(url.toURI());
        } catch (URISyntaxException e) {
            throw new IOException(e);
        }
        ByteBuffer buf = ByteBuffer.allocateDirect((int) Files.size(path) + 1);
        try (SeekableByteChannel ch = Files.newByteChannel(path)) {
            while (ch.read(buf) != -1) {
            }
        }
        buf.flip();
        return buf;
    }
}